#include <stdio.h>
int main()
{
    printf("Hello World");
    return 0;
}
void fun(int x)
{
    printf("%d", x);
}