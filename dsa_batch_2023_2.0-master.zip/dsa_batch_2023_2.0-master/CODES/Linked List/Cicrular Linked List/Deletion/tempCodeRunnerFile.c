
            previous=current;